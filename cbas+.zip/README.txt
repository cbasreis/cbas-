Edited by cbas 

for 1.16+

Credits:
fWhip
jolicraft
New Default +
john smith
SCARCROW Lab. & Asp_Blackhole
@alor79
ElTongo




